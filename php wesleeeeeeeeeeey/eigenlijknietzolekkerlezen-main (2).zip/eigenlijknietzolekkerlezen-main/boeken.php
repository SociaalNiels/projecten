<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>lekker Lezen</title>
</head>
<body>
  <link type="text/css" rel="stylesheet" media="screen" href="https://netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css"></link>

  <ul>
    <li><a style="font-size:40px" href="./index.php">HOME</a></li>
    <li><a style="font-size:40px" href="#boeken">BOEKEN</a></li>
    <li><a style="font-size:40px" href="./contact.php">CONTACT</a></li>
  </ul>
</div>
    <div class="flexbox-container">
        <div class="flexbox-item fixed">
          <img src="https://images.mind-books.nl/libris/book/cover/9789403108711?hash=f2d2607&width=160" alt="Book" width="125" height="200">
          <img src="https://images.mind-books.nl/libris/book/cover/9789402707991?hash=80f978e&width=160" alt="Book" width="125" height="200">
          <img src="https://images.mind-books.nl/libris/book/cover/9789400513716?hash=21d5e38&width=160" alt="Book" width="125" height="200">
          <img src="https://images.mind-books.nl/libris/book/cover/9789022591208?hash=4594fed&width=160" alt="Book" width="125" height="200">
          <img src="https://images.mind-books.nl/libris/book/cover/9789026352126?hash=&width=160" alt="Book" width="125" height="200">
          <img src="https://images.mind-books.nl/libris/book/cover/9789022591109?hash=c398b7a&width=160" alt="Book" width="125" height="200">
          <img src="https://images.mind-books.nl/libris/book/cover/9789022592809?hash=c55c2ca&width=160" alt="Book" width="125" height="200">
          <img src="https://images.mind-books.nl/libris/book/cover/9789024594894?hash=bdab81d&width=160" alt="Book" width="125" height="200">
          <img src="https://images.mind-books.nl/libris/book/cover/9789024582273?hash=dc73aec&width=160" alt="Book" width="125" height="200">
          <img src="https://images.mind-books.nl/libris/book/cover/9789026623844?hash=adfa969&width=160" alt="Book" width="125" height="200">
          <img src="https://images.mind-books.nl/libris/book/cover/9789048858675?hash=88e7d9d&width=160" alt="Book" width="125" height="200">
          <img src="https://images.mind-books.nl/libris/book/cover/9789038810638?hash=03eb1ef&width=160" alt="Book" width="125" height="200">
          <img src="https://images.mind-books.nl/libris/book/cover/9789022591208?hash=4594fed&width=160" alt="Book" width="125" height="200">
          <img src="https://images.mind-books.nl/libris/book/cover/9789026148026?hash=6ba2341&width=160" alt="Book" width="125" height="200">

<div class="footer">
<p><strong>Email: lekkerlezen@gmail.com Telefoonnummer: +31-655-5979-01</strong></p>

  </div>
</body>
</html>